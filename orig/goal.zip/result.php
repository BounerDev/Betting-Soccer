<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
      <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
      <title>Freekick.GG - Guess the Goalscorer</title>
      <meta name="description" content="You have 5 attempts to find out who scored this goal in the Premier League.">
      <meta property="og:title" content="Freekick.GG - Guess the Goalscorer">
      <meta property="og:site_name" content="Freekick.GG">
      <meta property="og:url" content="https://freekick.gg/">
      <meta property="og:description" content="You have 5 attempts to find out who scored this goal in the Premier League.">
      <meta property="og:type" content="website">
      <meta property="og:image" content="https://freekick.gg/img/og-image.png">
      <meta name="twitter:card" content="summary" />
      <meta name="twitter:title" content="Freekick.GG - Guess the Goalscorer" />
      <meta name="twitter:description" content="You have 5 attempts to find out who scored this goal in the Premier League." />
      <style>
         body {
         font-family: 'Inter';
         font-size: 0.875rem;
         font-weight: 400;
         -webkit-text-size-adjust: 100%;
         -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
         }
         .btn1 .icon {
         width: 1.25rem;
         height: 1.25rem;
         margin: 0 0.5rem 0;
         -webkit-margin-start: -0.25rem;
         margin-inline-start: -0.25rem;
         vertical-align: bottom;
         color: #656d77;
         }
         .icon {
         width: 1.25rem;
         height: 1.25rem;
         font-size: 1.25rem;
         vertical-align: bottom;
         stroke-width: 1.5;
         }
         .btn1 {
         display: inline-block;
         font-weight: 500;
         line-height: 1.4285714;
         color: #232e3c;
         text-align: center;
         vertical-align: middle;
         cursor: pointer;
         -webkit-user-select: none;
         -moz-user-select: none;
         -ms-user-select: none;
         user-select: none;
         background-color: transparent;
         border-color: rgba(101, 109, 119, 0.24);
         padding: 0.4375rem 1rem;
         font-size: 0.875rem;
         border-radius: 3px;
         transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
         }
         .text-container .info-section {
         max-width: 600px;
         margin: 80px auto 0;
         font-size: 18px;
         }
         .text-container * {
         font-family: "Source Sans Pro",sans-serif;
         color: #748490;
         }
         .main-footer {
         bottom: 0;
         height: 2.5rem; 
         text-align:center;
         width: 100%;
         }
         .main-footer ul {
         margin-bottom: 0;
         padding: 0;
         list-style: none;
         display: inline-block;
         }
         .main-footer li {
         display: inline-block;
         }
         .start-form {
         background: #fff;
         margin: 0 auto;
         box-shadow: 0 5px 20px rgb(0 0 0 / 10%);
         border-radius: 6px;
         padding: 25px;
         position: relative;
         }
      </style>
   </head>
   <body style="background-color: #f4f6fa;">
      <nav class="navbar navbar-expand-lg navbar-light" style="background-color:#fff; box-shadow: inset 0 -1px 0 0 rgb(101 109 119 / 16%);">
         <div class="container-fluid">
         <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
               <button type="button" class="btn btn1 btn-light" style="border:0px; color: #575656; opacity:0.7;" data-bs-toggle="modal" data-bs-target="#exampleModal" aria-current="page" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
                     <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                     <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                  </svg>
                  About
               </button>
            </li>
         </ul>
         <div class="d-flex pe-0 pe-md-2">
            <a href="" class="btn1 btn">
               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-activity" viewBox="0 0 16 16">
                  <path fill-rule="evenodd" d="M6 2a.5.5 0 0 1 .47.33L10 12.036l1.53-4.208A.5.5 0 0 1 12 7.5h3.5a.5.5 0 0 1 0 1h-3.15l-1.88 5.17a.5.5 0 0 1-.94 0L6 3.964 4.47 8.171A.5.5 0 0 1 4 8.5H.5a.5.5 0 0 1 0-1h3.15l1.88-5.17A.5.5 0 0 1 6 2Z"/>
               </svg>
            </a>
            </li>
         </div>
      </nav>
      <div class="container" style="margin-top:-30px; font-family: 'Source Sans Pro',sans-serif;">
         <div class="text-container">
            <div class="info-section">
               <div class="card">
                  <img src="goal2.jpg" class="card-img-top" style="height: 260px; width: 100%; object-fit: cover;" alt="...">
                  <div class="card-body">
                     <p class="card-text text-center">
                        <span class="opacity-100">The goalscorer was<br><strong x-text="playerName" class="text-lg text-gray-900">Eden Hazard!</strong></span>
                     </p>
                  </div>
               </div>
               <div class="mt-4 text-center">
                  <p>Share your score and help Freekick.GG go worldwide</p>
                  <div class="form-group">
                     <textarea class="form-control" id="exampleFormControlTextarea1"  disabled rows="3">https://freekick.gg 
✅⚫⚫⚫⚫</textarea>
                     <div class="mt-2">
                        <button class="btn btn-primary text-white" style="color:#fff;" type="submit">Share</button>
                        <a class="btn btn-success text-white" style="color:#fff;" target="_blank" href="https://www.youtube.com/watch?v=zZIpmR8BCcY">Watch the goal</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">About Freekick.GG</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
               </div>
               <div class="modal-body">
                  <p>
                     Welcome to your daily game by <a href="https://freekick.gg" style="color: #1f68bb; font-weight: 600;" class="text-decoration-none">Freekick.GG</a> where you guess who scored this goal — it can be overhead kick, freekick, long shot... All the goals have been scored in English competition (Premier League, FA Cup, EFL Cup).
                  </p>
                  <p>You have 5 attempts to find out who scored the goal with 5 different frames until you succeed and you can share your result at the end of the guessing game to your friends.
                  </p>
                  <p>You can contact us at <a href="contact@freekick.gg">contact@freekick.gg</a>.
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <script>
         $('body').on('click', '[data-toggle="modal"]', function(){
                 $($(this).data("target")+' .modal-body').load($(this).data("remote"));
             });
      </script>
      <!-- Optional JavaScript; choose one of the two! -->
      <!-- Option 1: Bootstrap Bundle with Popper -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
      <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Option 2: Separate Popper and Bootstrap JS -->
      <!--
         <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
         <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
         -->
   </body>
</html>